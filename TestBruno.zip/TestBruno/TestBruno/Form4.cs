﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using TestBruno;

namespace TestBruno
{
    public partial class Form4 : Form
    {

        public static SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True");
        

        public Form4()
        {
            InitializeComponent();
        }
      

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
           
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = " select * from Umowa";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                
                comboBox1.Items.Add(dr["Nazwa"].ToString());
              
            }
            con.Close();
            
            con.Open();
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = " select * from Tablica";
            cmd2.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            da2.Fill(dt2);
            foreach (DataRow dr2 in dt2.Rows)
            {

                comboBox2.Items.Add(dr2["Department"].ToString());

            }
            con.Close();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Umowa where Nazwa='"+comboBox1.SelectedItem.ToString()+"'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {

                textBox1.Text = dr["Komorka"].ToString();
                textBox2.Text = dr["Opis"].ToString();
            }
            con.Close();

        }

        private void Zapisz_Click(object sender, EventArgs e)
        {
            
            con.Open();
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = CommandType.Text;
            cmd3.CommandText = @"UPDATE Umowa SET Komorka = '"+ comboBox2.Text+"', Opis = '"+textBox2.Text+"' WHERE Nazwa ='"+ comboBox1.Text+"'";
            cmd3.ExecuteNonQuery();
            DataTable dt3 = new DataTable();
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            con.Close();
            MessageBox.Show("Zapisano umowę");
            Close();
            Form2 form2 = new Form2();

            Visible = false;
            form2.Show();
        }
    }
}

       
        
    
    

