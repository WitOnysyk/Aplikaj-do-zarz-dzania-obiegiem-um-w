﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using TestBruno;

namespace TestBruno
{
    public partial class Form3 : Form
    {
       
        public Form3()
        {
            InitializeComponent();
        }

        


        private void Form3_Load(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string sql = null;
            connetionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";
            sql = "select Id, Nazwa from Umowa";
            connection = new SqlConnection(connetionString);
            try
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                adapter.SelectCommand = command;
                adapter.Fill(ds);
                adapter.Dispose();
                command.Dispose();
                connection.Close();
                comboBox1.DataSource = ds.Tables[0];
                comboBox1.ValueMember = "Id";
                comboBox1.DisplayMember = "Nazwa";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }

            comboBox1.DataSource = ds.Tables[0];
            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "Nazwa";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection connection;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            connetionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";
            connection = new SqlConnection(connetionString);
            SqlCommand CmdSql = new SqlCommand("Delete from Umowa where Nazwa ="+"@Nazwa", connection);
            try
            {
                connection.Open();
                CmdSql.Parameters.AddWithValue("@Nazwa", comboBox1.Text);

                CmdSql.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Usunięto umowę");
                Close();
                Form2 form2 = new Form2();

               Visible = false;
                form2.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }
        }
    }
}
