﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using TestBruno;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
          
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string sql = null;
            connetionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";
            sql = "select Id, Department from Tablica";
            connection = new SqlConnection(connetionString);
            try
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                adapter.SelectCommand = command;
                adapter.Fill(ds);
                adapter.Dispose();
                command.Dispose();
                connection.Close();
                comboBox1.DataSource = ds.Tables[0];
                comboBox1.ValueMember = "Id";
                comboBox1.DisplayMember = "Department";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }

            comboBox1.DataSource = ds.Tables[0];
            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "Department";
        }
            private void button1_Click(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection connection;
           
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            connetionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";
            connection = new SqlConnection(connetionString);
            SqlCommand CmdSql = new SqlCommand("INSERT INTO [Umowa] (Nazwa,Komorka, Opis) VALUES (@Nazwa,@Komorka, @Opis)", connection);
            try {
                connection.Open();
                CmdSql.Parameters.AddWithValue("@Nazwa", textBox1.Text);
                CmdSql.Parameters.AddWithValue("@Komorka", comboBox1.Text);
                CmdSql.Parameters.AddWithValue("@Opis", textBox2.Text);
                CmdSql.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Dodano umowę");
                Close();
                Form2 form2 = new Form2();

                Visible = false;
                form2.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show("nie dodano umowy, błąd !");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }



        }
    
