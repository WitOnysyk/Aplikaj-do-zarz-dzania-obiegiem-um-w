﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WindowsFormsApplication1;

namespace TestBruno
    {
        public partial class Form2 : Form
        {
            private BindingSource bindingSource1 = new BindingSource();
            public Form2()
            {
                InitializeComponent();
            }
            private void GetData(string selectCommand)
            {

                try
                {
                    // Specify a connection string. Replace the given value with a 
                    // valid connection string for a Northwind SQL Server sample
                    // database accessible to your system.
                    String connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";


                    // Create a new data adapter based on the specified query.
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connectionString);

                    // Create a command builder to generate SQL update, insert, and
                    // delete commands based on selectCommand. These are used to
                    // update the database.
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

                    // Populate a new data table and bind it to the BindingSource.
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    bindingSource1.DataSource = table;

                    // Resize the DataGridView columns to fit the newly loaded content.
                    dataGridView1.AutoResizeColumns(
                        DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);
                }
                catch (SqlException)
                {
                    MessageBox.Show("To run this example, replace the value of the " +
                        "connectionString variable with a connection string that is " +
                        "valid for your system.");
                }
            }

            private void Form2_Load(object sender, EventArgs e)
            {
            // TODO: This line of code loads data into the 'database1DataSet.Umowa' table. You can move, or remove it, as needed.
            this.umowaTableAdapter.Fill(this.database1DataSet.Umowa);
            dataGridView1.DataSource = bindingSource1;
                GetData("select * from Umowa");

            }

            private void button1_Click(object sender, EventArgs e)
            {
                Form1 form1 = new Form1();
            
                Visible = false;
                form1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();

            Visible = false;
            form3.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
    
