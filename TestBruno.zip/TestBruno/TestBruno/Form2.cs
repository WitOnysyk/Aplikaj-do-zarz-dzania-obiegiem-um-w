﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WindowsFormsApplication1;

namespace TestBruno
    {
        public partial class Form2 : Form
        {

        String connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = ""C:\Users\WitO\Documents\Visual Studio 2015\Projects\TestBruno\TestBruno\Database1.mdf""; Integrated Security = True";

        private BindingSource bindingSource1 = new BindingSource();



        public Form2()
            {
                InitializeComponent();
            }

            private void GetData(string selectCommand)
            {

                try
                {
                    
   
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connectionString);
                
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

                  
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    bindingSource1.DataSource = table;
                
                    
                       
                }
                catch (SqlException)
                {
                    MessageBox.Show("To run this example, replace the value of the " +
                        "connectionString variable with a connection string that is " +
                        "valid for your system.");
                }
            }

        private void Form2_Load(object sender, EventArgs e)
       
        {
         
            this.umowaTableAdapter.Fill(this.database1DataSet.Umowa);
            dataGridView1.DataSource = bindingSource1;
            GetData("select * from Umowa");
         

        }

            private void button1_Click(object sender, EventArgs e)
            {
                Form1 form1 = new Form1();
            
                Visible = false;
                form1.Show();
        }

        
        private void button2_Click_1(object sender, EventArgs e)
        {
            
            Form3 form3 = new Form3();

           Visible = false;
            form3.Show();
           



        }

        private void edytujUmowe_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();

            Visible = false;
            form4.Show();
        }
    }
}
    
